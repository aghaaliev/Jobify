const Application = require('../models/application.model');
const Job = require('../models/job.model');
const User = require('../models/user.model');
const Company = require('../models/company.model');

// Apply for a job
exports.applyForJob = async (req, res) => {
  try {
    const { jobId } = req.params;
    const { coverLetter, resume } = req.body;
    const userId = req.userId;
    
    // Check if job exists
    const job = await Job.findByPk(jobId);
    if (!job) {
      return res.status(404).json({ message: 'Job not found' });
    }
    
    // Check if job is active
    if (!job.isActive) {
      return res.status(400).json({ message: 'This job is no longer accepting applications' });
    }
    
    // Check if deadline has passed
    if (new Date(job.deadline) < new Date()) {
      return res.status(400).json({ message: 'Application deadline has passed' });
    }
    
    // Check if user has already applied for this job
    const existingApplication = await Application.findOne({
      where: {
        jobId,
        userId
      }
    });
    
    if (existingApplication) {
      return res.status(400).json({ message: 'You have already applied for this job' });
    }
    
    // Create application
    const application = await Application.create({
      jobId,
      userId,
      coverLetter,
      resume,
      status: 'pending'
    });
    
    res.status(201).json({
      message: 'Application submitted successfully',
      application
    });
  } catch (error) {
    console.error('Apply for job error:', error);
    res.status(500).json({ message: 'Error submitting application', error: error.message });
  }
};

// Get user applications
exports.getUserApplications = async (req, res) => {
  try {
    const userId = req.userId;
    
    const applications = await Application.findAll({
      where: { userId },
      include: [
        {
          model: Job,
          as: 'job',
          include: [
            {
              model: Company,
              as: 'company',
              attributes: ['id', 'name', 'logo', 'industry', 'location']
            }
          ]
        }
      ],
      order: [['createdAt', 'DESC']]
    });
    
    res.status(200).json({ applications });
  } catch (error) {
    console.error('Get user applications error:', error);
    res.status(500).json({ message: 'Error fetching applications', error: error.message });
  }
};

// Get job applications (for employers)
exports.getJobApplications = async (req, res) => {
  try {
    const { jobId } = req.params;
    const userId = req.userId;
    
    // Check if job exists
    const job = await Job.findByPk(jobId, {
      include: [
        {
          model: Company,
          as: 'company'
        }
      ]
    });
    
    if (!job) {
      return res.status(404).json({ message: 'Job not found' });
    }
    
    // Check if user is authorized to view applications for this job
    if (job.company.userId !== userId) {
      return res.status(403).json({ message: 'You can only view applications for your own job postings' });
    }
    
    // Get applications
    const applications = await Application.findAll({
      where: { jobId },
      include: [
        {
          model: User,
          as: 'applicant',
          attributes: ['id', 'firstName', 'lastName', 'email', 'phone', 'location']
        }
      ],
      order: [['createdAt', 'DESC']]
    });
    
    res.status(200).json({ applications });
  } catch (error) {
    console.error('Get job applications error:', error);
    res.status(500).json({ message: 'Error fetching applications', error: error.message });
  }
};

// Update application status (for employers)
exports.updateApplicationStatus = async (req, res) => {
  try {
    const { applicationId } = req.params;
    const { status, notes } = req.body;
    const userId = req.userId;
    
    // Check if application exists
    const application = await Application.findByPk(applicationId, {
      include: [
        {
          model: Job,
          as: 'job',
          include: [
            {
              model: Company,
              as: 'company'
            }
          ]
        }
      ]
    });
    
    if (!application) {
      return res.status(404).json({ message: 'Application not found' });
    }
    
    // Check if user is authorized to update this application
    if (application.job.company.userId !== userId) {
      return res.status(403).json({ message: 'You can only update applications for your own job postings' });
    }
    
    // Update application
    const updatedApplication = await application.update({
      status,
      notes
    });
    
    res.status(200).json({
      message: 'Application status updated successfully',
      application: updatedApplication
    });
  } catch (error) {
    console.error('Update application status error:', error);
    res.status(500).json({ message: 'Error updating application status', error: error.message });
  }
};

// Get application details
exports.getApplicationById = async (req, res) => {
  try {
    const { applicationId } = req.params;
    const userId = req.userId;
    
    // Check if application exists
    const application = await Application.findByPk(applicationId, {
      include: [
        {
          model: Job,
          as: 'job',
          include: [
            {
              model: Company,
              as: 'company'
            }
          ]
        },
        {
          model: User,
          as: 'applicant',
          attributes: ['id', 'firstName', 'lastName', 'email', 'phone', 'location']
        }
      ]
    });
    
    if (!application) {
      return res.status(404).json({ message: 'Application not found' });
    }
    
    // Check if user is authorized to view this application
    if (application.userId !== userId && application.job.company.userId !== userId) {
      return res.status(403).json({ message: 'You can only view your own applications or applications for your job postings' });
    }
    
    res.status(200).json({ application });
  } catch (error) {
    console.error('Get application by ID error:', error);
    res.status(500).json({ message: 'Error fetching application', error: error.message });
  }
};
