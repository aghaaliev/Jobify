const Job = require('../models/job.model');
const Company = require('../models/company.model');
const Category = require('../models/category.model');
const { Op } = require('sequelize');

// Get all jobs with filtering
exports.getAllJobs = async (req, res) => {
  try {
    const {
      title,
      location,
      category,
      type,
      experienceLevel,
      salaryMin,
      salaryMax,
      companyId,
      isActive,
      isFeatured,
      limit = 10,
      offset = 0,
      sortBy = 'createdAt',
      sortOrder = 'DESC'
    } = req.query;

    // Build filter conditions
    const whereConditions = {};
    
    if (title) {
      whereConditions.title = { [Op.iLike]: `%${title}%` };
    }
    
    if (location) {
      whereConditions.location = { [Op.iLike]: `%${location}%` };
    }
    
    if (category) {
      whereConditions.category = category;
    }
    
    if (type) {
      whereConditions.type = type;
    }
    
    if (experienceLevel) {
      whereConditions.experienceLevel = experienceLevel;
    }
    
    if (salaryMin) {
      whereConditions.salaryMin = { [Op.gte]: parseInt(salaryMin) };
    }
    
    if (salaryMax) {
      whereConditions.salaryMax = { [Op.lte]: parseInt(salaryMax) };
    }
    
    if (companyId) {
      whereConditions.companyId = companyId;
    }
    
    if (isActive !== undefined) {
      whereConditions.isActive = isActive === 'true';
    } else {
      // By default, only show active jobs
      whereConditions.isActive = true;
    }
    
    if (isFeatured !== undefined) {
      whereConditions.isFeatured = isFeatured === 'true';
    }

    // Get jobs with pagination and sorting
    const { count, rows: jobs } = await Job.findAndCountAll({
      where: whereConditions,
      include: [
        {
          model: Company,
          as: 'company',
          attributes: ['id', 'name', 'logo', 'industry', 'location']
        }
      ],
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [[sortBy, sortOrder]],
      distinct: true
    });

    res.status(200).json({
      totalItems: count,
      jobs,
      currentPage: Math.floor(parseInt(offset) / parseInt(limit)) + 1,
      totalPages: Math.ceil(count / parseInt(limit))
    });
  } catch (error) {
    console.error('Get all jobs error:', error);
    res.status(500).json({ message: 'Error fetching jobs', error: error.message });
  }
};

// Get job by ID
exports.getJobById = async (req, res) => {
  try {
    const jobId = req.params.id;
    
    const job = await Job.findByPk(jobId, {
      include: [
        {
          model: Company,
          as: 'company',
          attributes: ['id', 'name', 'logo', 'industry', 'location', 'website', 'size', 'founded']
        }
      ]
    });
    
    if (!job) {
      return res.status(404).json({ message: 'Job not found' });
    }
    
    // Increment view count
    job.views += 1;
    await job.save();
    
    res.status(200).json({ job });
  } catch (error) {
    console.error('Get job by ID error:', error);
    res.status(500).json({ message: 'Error fetching job', error: error.message });
  }
};

// Create a new job
exports.createJob = async (req, res) => {
  try {
    const {
      title,
      description,
      responsibilities,
      requirements,
      benefits,
      location,
      type,
      category,
      experienceLevel,
      educationLevel,
      salaryMin,
      salaryMax,
      currency,
      skills,
      deadline,
      companyId,
      isFeatured
    } = req.body;
    
    // Check if company exists
    const company = await Company.findByPk(companyId);
    if (!company) {
      return res.status(404).json({ message: 'Company not found' });
    }
    
    // Check if company belongs to the user
    if (company.userId !== req.userId) {
      return res.status(403).json({ message: 'You can only post jobs for your own company' });
    }
    
    // Create job
    const job = await Job.create({
      title,
      description,
      responsibilities,
      requirements,
      benefits,
      location,
      type,
      category,
      experienceLevel,
      educationLevel,
      salaryMin,
      salaryMax,
      currency,
      skills,
      deadline,
      companyId,
      postedBy: req.userId,
      isFeatured: isFeatured || false
    });
    
    res.status(201).json({
      message: 'Job created successfully',
      job
    });
  } catch (error) {
    console.error('Create job error:', error);
    res.status(500).json({ message: 'Error creating job', error: error.message });
  }
};

// Update a job
exports.updateJob = async (req, res) => {
  try {
    const jobId = req.params.id;
    
    const job = await Job.findByPk(jobId);
    if (!job) {
      return res.status(404).json({ message: 'Job not found' });
    }
    
    // Check if user is authorized to update this job
    if (job.postedBy !== req.userId) {
      return res.status(403).json({ message: 'You can only update your own job postings' });
    }
    
    // Update job fields
    const updatedJob = await job.update(req.body);
    
    res.status(200).json({
      message: 'Job updated successfully',
      job: updatedJob
    });
  } catch (error) {
    console.error('Update job error:', error);
    res.status(500).json({ message: 'Error updating job', error: error.message });
  }
};

// Delete a job
exports.deleteJob = async (req, res) => {
  try {
    const jobId = req.params.id;
    
    const job = await Job.findByPk(jobId);
    if (!job) {
      return res.status(404).json({ message: 'Job not found' });
    }
    
    // Check if user is authorized to delete this job
    if (job.postedBy !== req.userId) {
      return res.status(403).json({ message: 'You can only delete your own job postings' });
    }
    
    // Delete job
    await job.destroy();
    
    res.status(200).json({ message: 'Job deleted successfully' });
  } catch (error) {
    console.error('Delete job error:', error);
    res.status(500).json({ message: 'Error deleting job', error: error.message });
  }
};

// Get featured jobs
exports.getFeaturedJobs = async (req, res) => {
  try {
    const limit = req.query.limit || 4;
    
    const featuredJobs = await Job.findAll({
      where: {
        isFeatured: true,
        isActive: true
      },
      include: [
        {
          model: Company,
          as: 'company',
          attributes: ['id', 'name', 'logo', 'industry', 'location']
        }
      ],
      limit: parseInt(limit),
      order: [['createdAt', 'DESC']]
    });
    
    res.status(200).json({ featuredJobs });
  } catch (error) {
    console.error('Get featured jobs error:', error);
    res.status(500).json({ message: 'Error fetching featured jobs', error: error.message });
  }
};

// Get job categories with count
exports.getJobCategories = async (req, res) => {
  try {
    const categories = await Category.findAll({
      attributes: ['id', 'name', 'icon', 'description']
    });
    
    // Get job count for each category
    const categoriesWithCount = await Promise.all(
      categories.map(async (category) => {
        const count = await Job.count({
          where: {
            category: category.name,
            isActive: true
          }
        });
        
        return {
          id: category.id,
          name: category.name,
          icon: category.icon,
          description: category.description,
          jobCount: count
        };
      })
    );
    
    res.status(200).json({ categories: categoriesWithCount });
  } catch (error) {
    console.error('Get job categories error:', error);
    res.status(500).json({ message: 'Error fetching job categories', error: error.message });
  }
};

// Search jobs
exports.searchJobs = async (req, res) => {
  try {
    const { query, location, limit = 10, offset = 0 } = req.query;
    
    const whereConditions = {
      isActive: true
    };
    
    if (query) {
      whereConditions[Op.or] = [
        { title: { [Op.iLike]: `%${query}%` } },
        { description: { [Op.iLike]: `%${query}%` } },
        { skills: { [Op.contains]: [query] } }
      ];
    }
    
    if (location) {
      whereConditions.location = { [Op.iLike]: `%${location}%` };
    }
    
    const { count, rows: jobs } = await Job.findAndCountAll({
      where: whereConditions,
      include: [
        {
          model: Company,
          as: 'company',
          attributes: ['id', 'name', 'logo', 'industry', 'location']
        }
      ],
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [['createdAt', 'DESC']],
      distinct: true
    });
    
    res.status(200).json({
      totalItems: count,
      jobs,
      currentPage: Math.floor(parseInt(offset) / parseInt(limit)) + 1,
      totalPages: Math.ceil(count / parseInt(limit))
    });
  } catch (error) {
    console.error('Search jobs error:', error);
    res.status(500).json({ message: 'Error searching jobs', error: error.message });
  }
};
