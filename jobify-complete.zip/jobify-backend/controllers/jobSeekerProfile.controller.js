const { Op } = require('sequelize');
const JobSeekerProfile = require('../models/jobSeekerProfile.model');
const User = require('../models/user.model');

// Create or update job seeker profile
exports.createOrUpdateProfile = async (req, res) => {
  try {
    const userId = req.userId;
    
    // Check if profile already exists
    let profile = await JobSeekerProfile.findOne({
      where: { userId }
    });
    
    if (profile) {
      // Update existing profile
      profile = await profile.update(req.body);
      return res.status(200).json({
        message: 'Profile updated successfully',
        profile
      });
    } else {
      // Create new profile
      profile = await JobSeekerProfile.create({
        ...req.body,
        userId
      });
      return res.status(201).json({
        message: 'Profile created successfully',
        profile
      });
    }
  } catch (error) {
    console.error('Create/update profile error:', error);
    res.status(500).json({ message: 'Error creating/updating profile', error: error.message });
  }
};

// Get job seeker profile by user ID
exports.getProfileByUserId = async (req, res) => {
  try {
    const userId = req.params.userId || req.userId;
    
    const profile = await JobSeekerProfile.findOne({
      where: { userId },
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'firstName', 'lastName', 'email', 'phone', 'location']
        }
      ]
    });
    
    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }
    
    // If profile is not public and not the owner, restrict access
    if (!profile.isPublic && userId !== req.userId) {
      return res.status(403).json({ message: 'This profile is private' });
    }
    
    res.status(200).json({ profile });
  } catch (error) {
    console.error('Get profile error:', error);
    res.status(500).json({ message: 'Error fetching profile', error: error.message });
  }
};

// Get current user's profile
exports.getCurrentUserProfile = async (req, res) => {
  try {
    const userId = req.userId;
    
    const profile = await JobSeekerProfile.findOne({
      where: { userId }
    });
    
    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }
    
    res.status(200).json({ profile });
  } catch (error) {
    console.error('Get current user profile error:', error);
    res.status(500).json({ message: 'Error fetching profile', error: error.message });
  }
};

// Get all public job seeker profiles
exports.getAllPublicProfiles = async (req, res) => {
  try {
    const {
      title,
      skills,
      location,
      limit = 10,
      offset = 0,
      sortBy = 'createdAt',
      sortOrder = 'DESC'
    } = req.query;
    
    // Build filter conditions
    const whereConditions = {
      isPublic: true,
      isActive: true
    };
    
    if (title) {
      whereConditions.title = { [Op.iLike]: `%${title}%` };
    }
    
    if (skills) {
      whereConditions.skills = { [Op.contains]: [skills] };
    }
    
    if (location) {
      whereConditions.location = { [Op.iLike]: `%${location}%` };
    }
    
    // Get profiles with pagination and sorting
    const { count, rows: profiles } = await JobSeekerProfile.findAndCountAll({
      where: whereConditions,
      include: [
        {
          model: User,
          as: 'user',
          attributes: ['id', 'firstName', 'lastName', 'location']
        }
      ],
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [[sortBy, sortOrder]]
    });
    
    res.status(200).json({
      totalItems: count,
      profiles,
      currentPage: Math.floor(parseInt(offset) / parseInt(limit)) + 1,
      totalPages: Math.ceil(count / parseInt(limit))
    });
  } catch (error) {
    console.error('Get all public profiles error:', error);
    res.status(500).json({ message: 'Error fetching profiles', error: error.message });
  }
};

// Toggle profile visibility
exports.toggleProfileVisibility = async (req, res) => {
  try {
    const userId = req.userId;
    
    const profile = await JobSeekerProfile.findOne({
      where: { userId }
    });
    
    if (!profile) {
      return res.status(404).json({ message: 'Profile not found' });
    }
    
    // Toggle visibility
    profile.isPublic = !profile.isPublic;
    await profile.save();
    
    res.status(200).json({
      message: `Profile is now ${profile.isPublic ? 'public' : 'private'}`,
      isPublic: profile.isPublic
    });
  } catch (error) {
    console.error('Toggle profile visibility error:', error);
    res.status(500).json({ message: 'Error toggling profile visibility', error: error.message });
  }
};
