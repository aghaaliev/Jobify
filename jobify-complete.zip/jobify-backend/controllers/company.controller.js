const Company = require('../models/company.model');
const Job = require('../models/job.model');
const { Op } = require('sequelize');

// Get all companies
exports.getAllCompanies = async (req, res) => {
  try {
    const {
      name,
      industry,
      location,
      limit = 10,
      offset = 0,
      sortBy = 'createdAt',
      sortOrder = 'DESC'
    } = req.query;

    // Build filter conditions
    const whereConditions = {};
    
    if (name) {
      whereConditions.name = { [Op.iLike]: `%${name}%` };
    }
    
    if (industry) {
      whereConditions.industry = { [Op.iLike]: `%${industry}%` };
    }
    
    if (location) {
      whereConditions.location = { [Op.iLike]: `%${location}%` };
    }

    // Get companies with pagination and sorting
    const { count, rows: companies } = await Company.findAndCountAll({
      where: whereConditions,
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [[sortBy, sortOrder]],
      attributes: { exclude: ['userId'] }
    });

    // Get job count for each company
    const companiesWithJobCount = await Promise.all(
      companies.map(async (company) => {
        const jobCount = await Job.count({
          where: {
            companyId: company.id,
            isActive: true
          }
        });
        
        return {
          ...company.toJSON(),
          jobCount
        };
      })
    );

    res.status(200).json({
      totalItems: count,
      companies: companiesWithJobCount,
      currentPage: Math.floor(parseInt(offset) / parseInt(limit)) + 1,
      totalPages: Math.ceil(count / parseInt(limit))
    });
  } catch (error) {
    console.error('Get all companies error:', error);
    res.status(500).json({ message: 'Error fetching companies', error: error.message });
  }
};

// Get company by ID
exports.getCompanyById = async (req, res) => {
  try {
    const companyId = req.params.id;
    
    const company = await Company.findByPk(companyId, {
      attributes: { exclude: ['userId'] }
    });
    
    if (!company) {
      return res.status(404).json({ message: 'Company not found' });
    }
    
    // Get active jobs for this company
    const jobs = await Job.findAll({
      where: {
        companyId,
        isActive: true
      },
      order: [['createdAt', 'DESC']]
    });
    
    res.status(200).json({
      company,
      jobs,
      jobCount: jobs.length
    });
  } catch (error) {
    console.error('Get company by ID error:', error);
    res.status(500).json({ message: 'Error fetching company', error: error.message });
  }
};

// Create a new company
exports.createCompany = async (req, res) => {
  try {
    const {
      name,
      industry,
      description,
      logo,
      website,
      location,
      size,
      founded,
      mission,
      values,
      benefits,
      socialMedia
    } = req.body;
    
    // Check if user already has a company
    const existingCompany = await Company.findOne({
      where: { userId: req.userId }
    });
    
    if (existingCompany) {
      return res.status(400).json({ message: 'You already have a company registered' });
    }
    
    // Create company
    const company = await Company.create({
      name,
      industry,
      description,
      logo,
      website,
      location,
      size,
      founded,
      mission,
      values,
      benefits,
      socialMedia,
      userId: req.userId
    });
    
    res.status(201).json({
      message: 'Company created successfully',
      company
    });
  } catch (error) {
    console.error('Create company error:', error);
    res.status(500).json({ message: 'Error creating company', error: error.message });
  }
};

// Update a company
exports.updateCompany = async (req, res) => {
  try {
    const companyId = req.params.id;
    
    const company = await Company.findByPk(companyId);
    if (!company) {
      return res.status(404).json({ message: 'Company not found' });
    }
    
    // Check if user is authorized to update this company
    if (company.userId !== req.userId) {
      return res.status(403).json({ message: 'You can only update your own company' });
    }
    
    // Update company fields
    const updatedCompany = await company.update(req.body);
    
    res.status(200).json({
      message: 'Company updated successfully',
      company: updatedCompany
    });
  } catch (error) {
    console.error('Update company error:', error);
    res.status(500).json({ message: 'Error updating company', error: error.message });
  }
};

// Get top companies (with most job postings)
exports.getTopCompanies = async (req, res) => {
  try {
    const limit = req.query.limit || 4;
    
    // Get all companies
    const companies = await Company.findAll({
      attributes: { exclude: ['userId'] }
    });
    
    // Get job count for each company
    const companiesWithJobCount = await Promise.all(
      companies.map(async (company) => {
        const jobCount = await Job.count({
          where: {
            companyId: company.id,
            isActive: true
          }
        });
        
        return {
          ...company.toJSON(),
          jobCount
        };
      })
    );
    
    // Sort by job count and limit
    const topCompanies = companiesWithJobCount
      .sort((a, b) => b.jobCount - a.jobCount)
      .slice(0, parseInt(limit));
    
    res.status(200).json({ topCompanies });
  } catch (error) {
    console.error('Get top companies error:', error);
    res.status(500).json({ message: 'Error fetching top companies', error: error.message });
  }
};

// Get company jobs
exports.getCompanyJobs = async (req, res) => {
  try {
    const companyId = req.params.id;
    
    const company = await Company.findByPk(companyId);
    if (!company) {
      return res.status(404).json({ message: 'Company not found' });
    }
    
    const {
      isActive = true,
      limit = 10,
      offset = 0,
      sortBy = 'createdAt',
      sortOrder = 'DESC'
    } = req.query;
    
    // Get jobs for this company
    const { count, rows: jobs } = await Job.findAndCountAll({
      where: {
        companyId,
        isActive: isActive === 'true'
      },
      limit: parseInt(limit),
      offset: parseInt(offset),
      order: [[sortBy, sortOrder]]
    });
    
    res.status(200).json({
      totalItems: count,
      jobs,
      currentPage: Math.floor(parseInt(offset) / parseInt(limit)) + 1,
      totalPages: Math.ceil(count / parseInt(limit))
    });
  } catch (error) {
    console.error('Get company jobs error:', error);
    res.status(500).json({ message: 'Error fetching company jobs', error: error.message });
  }
};
