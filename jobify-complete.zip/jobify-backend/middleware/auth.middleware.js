const jwt = require('jsonwebtoken');
const User = require('../models/user.model');

// Middleware to verify JWT token and add user ID to request
const verifyToken = async (req, res, next) => {
  try {
    // Get token from Authorization header
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ message: 'No token provided' });
    }
    
    const token = authHeader.split(' ')[1];
    
    // Verify token
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Add user ID to request
    req.userId = decoded.id;
    req.userRole = decoded.role;
    
    next();
  } catch (error) {
    if (error.name === 'TokenExpiredError') {
      return res.status(401).json({ message: 'Token expired' });
    }
    
    if (error.name === 'JsonWebTokenError') {
      return res.status(401).json({ message: 'Invalid token' });
    }
    
    console.error('Auth middleware error:', error);
    return res.status(500).json({ message: 'Authentication error', error: error.message });
  }
};

// Middleware to check if user is an employer
const isEmployer = (req, res, next) => {
  if (req.userRole !== 'employer' && req.userRole !== 'admin') {
    return res.status(403).json({ message: 'Access denied. Employer role required.' });
  }
  next();
};

// Middleware to check if user is a job seeker
const isJobSeeker = (req, res, next) => {
  if (req.userRole !== 'jobseeker' && req.userRole !== 'admin') {
    return res.status(403).json({ message: 'Access denied. Job seeker role required.' });
  }
  next();
};

// Middleware to check if user is an admin
const isAdmin = (req, res, next) => {
  if (req.userRole !== 'admin') {
    return res.status(403).json({ message: 'Access denied. Admin role required.' });
  }
  next();
};

module.exports = {
  verifyToken,
  isEmployer,
  isJobSeeker,
  isAdmin
};
