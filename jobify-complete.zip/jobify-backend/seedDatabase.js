const { sequelize } = require('./config/database');
const User = require('./models/user.model');
const Company = require('./models/company.model');
const Job = require('./models/job.model');
const Category = require('./models/category.model');
const JobSeekerProfile = require('./models/jobSeekerProfile.model');
const Application = require('./models/application.model');
const bcrypt = require('bcryptjs');

// Sample data for initial database setup
const seedDatabase = async () => {
  try {
    // Sync all models with database
    await sequelize.sync({ force: true });
    console.log('Database synced successfully');

    // Create categories
    const categories = await Category.bulkCreate([
      { name: 'Information Technology', icon: 'computer', description: 'Software development, IT support, network administration' },
      { name: 'Finance', icon: 'money', description: 'Accounting, banking, financial analysis' },
      { name: 'Marketing', icon: 'bullhorn', description: 'Digital marketing, brand management, market research' },
      { name: 'Sales', icon: 'chart-line', description: 'B2B sales, retail, account management' },
      { name: 'Customer Service', icon: 'headset', description: 'Customer support, call center, client relations' },
      { name: 'Human Resources', icon: 'users', description: 'Recruitment, HR management, training' },
      { name: 'Engineering', icon: 'cogs', description: 'Civil, mechanical, electrical engineering' },
      { name: 'Healthcare', icon: 'heartbeat', description: 'Medical, nursing, healthcare administration' }
    ]);
    console.log('Categories created successfully');

    // Create admin user
    const adminPassword = await bcrypt.hash('admin123', 10);
    const admin = await User.create({
      firstName: 'Admin',
      lastName: 'User',
      email: 'admin@jobiffy.az',
      password: adminPassword,
      role: 'admin',
      location: 'Baku, Azerbaijan'
    });
    console.log('Admin user created successfully');

    // Create employer users
    const employerPassword = await bcrypt.hash('employer123', 10);
    const employers = await User.bulkCreate([
      {
        firstName: 'John',
        lastName: 'Smith',
        email: 'john@techsolutions.az',
        password: employerPassword,
        role: 'employer',
        location: 'Baku, Azerbaijan'
      },
      {
        firstName: 'Sarah',
        lastName: 'Johnson',
        email: 'sarah@financeplus.az',
        password: employerPassword,
        role: 'employer',
        location: 'Baku, Azerbaijan'
      },
      {
        firstName: 'Michael',
        lastName: 'Brown',
        email: 'michael@marketingpro.az',
        password: employerPassword,
        role: 'employer',
        location: 'Baku, Azerbaijan'
      }
    ]);
    console.log('Employer users created successfully');

    // Create companies
    const companies = await Company.bulkCreate([
      {
        name: 'Tech Solutions',
        industry: 'Information Technology',
        description: 'Leading IT company specializing in software development and IT consulting',
        logo: 'TS',
        website: 'techsolutions.az',
        location: 'Baku, Azerbaijan',
        size: '51-200 employees',
        founded: 2015,
        mission: 'To empower businesses through innovative technology solutions',
        values: ['Innovation', 'Quality', 'Customer satisfaction'],
        benefits: ['Competitive salary', 'Health insurance', 'Professional development'],
        socialMedia: {
          linkedin: 'linkedin.com/company/techsolutions-az',
          facebook: 'facebook.com/techsolutionsaz'
        },
        userId: employers[0].id
      },
      {
        name: 'Finance Plus',
        industry: 'Finance',
        description: 'Financial services company providing accounting and consulting services',
        logo: 'FP',
        website: 'financeplus.az',
        location: 'Baku, Azerbaijan',
        size: '11-50 employees',
        founded: 2018,
        mission: 'To help businesses achieve financial success through expert guidance',
        values: ['Integrity', 'Excellence', 'Teamwork'],
        benefits: ['Flexible hours', 'Training opportunities', 'Performance bonuses'],
        socialMedia: {
          linkedin: 'linkedin.com/company/financeplus-az',
          facebook: 'facebook.com/financeplusaz'
        },
        userId: employers[1].id
      },
      {
        name: 'Marketing Pro',
        industry: 'Marketing',
        description: 'Full-service marketing agency specializing in digital marketing',
        logo: 'MP',
        website: 'marketingpro.az',
        location: 'Baku, Azerbaijan',
        size: '11-50 employees',
        founded: 2019,
        mission: 'To help brands connect with their audience through creative marketing',
        values: ['Creativity', 'Results-driven', 'Collaboration'],
        benefits: ['Creative work environment', 'Remote work options', 'Industry events'],
        socialMedia: {
          linkedin: 'linkedin.com/company/marketingpro-az',
          facebook: 'facebook.com/marketingproaz'
        },
        userId: employers[2].id
      }
    ]);
    console.log('Companies created successfully');

    // Create job seeker users
    const jobSeekerPassword = await bcrypt.hash('jobseeker123', 10);
    const jobSeekers = await User.bulkCreate([
      {
        firstName: 'Ali',
        lastName: 'Mammadov',
        email: 'ali@example.com',
        password: jobSeekerPassword,
        role: 'jobseeker',
        phone: '+994 50 123 4567',
        location: 'Baku, Azerbaijan'
      },
      {
        firstName: 'Leyla',
        lastName: 'Aliyeva',
        email: 'leyla@example.com',
        password: jobSeekerPassword,
        role: 'jobseeker',
        phone: '+994 55 987 6543',
        location: 'Baku, Azerbaijan'
      },
      {
        firstName: 'Farid',
        lastName: 'Huseynov',
        email: 'farid@example.com',
        password: jobSeekerPassword,
        role: 'jobseeker',
        phone: '+994 70 456 7890',
        location: 'Baku, Azerbaijan'
      }
    ]);
    console.log('Job seeker users created successfully');

    // Create job seeker profiles
    const jobSeekerProfiles = await JobSeekerProfile.bulkCreate([
      {
        title: 'Senior Software Developer',
        about: 'Experienced software developer with 5+ years in web development',
        skills: ['JavaScript', 'React', 'Node.js', 'PostgreSQL', 'TypeScript'],
        experience: JSON.stringify([
          {
            title: 'Senior Developer',
            company: 'ABC Tech',
            location: 'Baku',
            startDate: '2020-01',
            endDate: null,
            current: true,
            description: 'Leading development team for web applications'
          },
          {
            title: 'Web Developer',
            company: 'XYZ Solutions',
            location: 'Baku',
            startDate: '2018-03',
            endDate: '2019-12',
            current: false,
            description: 'Developed and maintained client websites'
          }
        ]),
        education: JSON.stringify([
          {
            degree: 'Bachelor of Computer Science',
            institution: 'Azerbaijan Technical University',
            location: 'Baku',
            startDate: '2014',
            endDate: '2018'
          }
        ]),
        languages: JSON.stringify([
          { language: 'Azerbaijani', proficiency: 'Native' },
          { language: 'English', proficiency: 'Fluent' },
          { language: 'Russian', proficiency: 'Intermediate' }
        ]),
        availability: JSON.stringify({
          immediate: true,
          notice: '2 weeks',
          type: ['Full-time', 'Remote']
        }),
        preferredJobs: ['Software Developer', 'Full Stack Developer', 'Frontend Developer'],
        preferredIndustries: ['Information Technology', 'Fintech', 'E-commerce'],
        salaryMin: 3000,
        salaryMax: 5000,
        currency: 'AZN',
        linkedin: 'linkedin.com/in/alimammadov',
        github: 'github.com/alimammadov',
        portfolio: 'alimammadov.com',
        isActive: true,
        isPublic: true,
        userId: jobSeekers[0].id
      },
      {
        title: 'Marketing Specialist',
        about: 'Creative marketing professional with experience in digital marketing campaigns',
        skills: ['Social Media Marketing', 'Content Creation', 'SEO', 'Google Analytics', 'Email Marketing'],
        experience: JSON.stringify([
          {
            title: 'Marketing Specialist',
            company: 'Brand Agency',
            location: 'Baku',
            startDate: '2019-06',
            endDate: null,
            current: true,
            description: 'Managing social media accounts and digital marketing campaigns'
          },
          {
            title: 'Marketing Assistant',
            company: 'Retail Group',
            location: 'Baku',
            startDate: '2018-01',
            endDate: '2019-05',
            current: false,
            description: 'Assisted with marketing activities and event organization'
          }
        ]),
        education: JSON.stringify([
          {
            degree: 'Bachelor of Business Administration',
            institution: 'Azerbaijan State Economic University',
            location: 'Baku',
            startDate: '2014',
            endDate: '2018'
          }
        ]),
        languages: JSON.stringify([
          { language: 'Azerbaijani', proficiency: 'Native' },
          { language: 'English', proficiency: 'Fluent' },
          { language: 'Turkish', proficiency: 'Intermediate' }
        ]),
        availability: JSON.stringify({
          immediate: false,
          notice: '1 month',
          type: ['Full-time', 'Part-time']
        }),
        preferredJobs: ['Marketing Specialist', 'Social Media Manager', 'Content Creator'],
        preferredIndustries: ['Marketing', 'Advertising', 'Media'],
        salaryMin: 1500,
        salaryMax: 2500,
        currency: 'AZN',
        linkedin: 'linkedin.com/in/leylaaliyeva',
        isActive: true,
        isPublic: true,
        userId: jobSeekers[1].id
      },
      {
        title: 'Financial Analyst',
        about: 'Detail-oriented financial analyst with strong analytical skills',
        skills: ['Financial Analysis', 'Excel', 'Financial Modeling', 'Data Analysis', 'Reporting'],
        experience: JSON.stringify([
          {
            title: 'Financial Analyst',
            company: 'Investment Bank',
            location: 'Baku',
            startDate: '2020-03',
            endDate: null,
            current: true,
            description: 'Performing financial analysis and creating reports'
          },
          {
            title: 'Junior Accountant',
            company: 'Accounting Firm',
            location: 'Baku',
            startDate: '2018-09',
            endDate: '2020-02',
            current: false,
            description: 'Assisted with accounting tasks and financial reporting'
          }
        ]),
        education: JSON.stringify([
          {
            degree: 'Master of Finance',
            institution: 'Azerbaijan State Economic University',
            location: 'Baku',
            startDate: '2018',
            endDate: '2020'
          },
          {
            degree: 'Bachelor of Finance',
            institution: 'Azerbaijan State Economic University',
            location: 'Baku',
            startDate: '2014',
            endDate: '2018'
          }
        ]),
        languages: JSON.stringify([
          { language: 'Azerbaijani', proficiency: 'Native' },
          { language: 'English', proficiency: 'Advanced' },
          { language: 'Russian', proficiency: 'Fluent' }
        ]),
        availability: JSON.stringify({
          immediate: false,
          notice: '1 month',
          type: ['Full-time']
        }),
        preferredJobs: ['Financial Analyst', 'Investment Analyst', 'Financial Consultant'],
        preferredIndustries: ['Finance', 'Banking', 'Investment'],
        salaryMin: 2000,
        salaryMax: 3500,
        currency: 'AZN',
        linkedin: 'linkedin.com/in/faridhuseynov',
        isActive: true,
        isPublic: true,
        userId: jobSeekers[2].id
      }
    ]);
    console.log('Job seeker profiles created successfully');

    // Create jobs
    const oneMonthFromNow = new Date();
    oneMonthFromNow.setMonth(oneMonthFromNow.getMonth() + 1);
    
    const twoMonthsFromNow = new Date();
    twoMonthsFromNow.setMonth(twoMonthsFromNow.getMonth() + 2);
    
    const jobs = await Job.bulkCreate([
      {
        title: 'Senior Software Engineer',
        description: 'We are looking for an experienced Software Engineer to join our development team.',
        responsibilities: [
          'Design and develop high-quality software solutions',
          'Collaborate with cross-functional teams',
          'Participate in code reviews and mentor junior developers',
          'Troubleshoot and debug applications'
        ],
        requirements: [
          '5+ years of experience in software development',
          'Strong knowledge of JavaScript, React, and Node.js',
          'Experience with database design and SQL',
          'Bachelor\'s degree in Computer Science or related field'
        ],
        benefits: [
          'Competitive salary',
          'Health insurance',
          'Professional development opportunities',
          'Flexible working hours'
        ],
        location: 'Baku, Azerbaijan',
        type: 'Full-time',
        category: 'Information Technology',
        experienceLevel: 'Senior Level',
        educationLevel: 'Bachelor\'s Degree',
        salaryMin: 3500,
        salaryMax: 5000,
        currency: 'AZN',
        skills: ['JavaScript', 'React', 'Node.js', 'PostgreSQL', 'TypeScript'],
        deadline: twoMonthsFromNow,
        isActive: true,
        isFeatured: true,
        companyId: companies[0].id,
        postedBy: employers[0].id
      },
      {
        title: 'Frontend Developer',
        description: 'Join our team as a Frontend Developer and create amazing user experiences.',
        responsibilities: [
          'Develop new user-facing features',
          'Build reusable components and libraries',
          'Optimize applications for maximum speed and scalability',
          'Collaborate with designers and backend developers'
        ],
        requirements: [
          '3+ years of experience in frontend development',
          'Proficiency in HTML, CSS, JavaScript, and React',
          'Experience with responsive design',
          'Knowledge of modern frontend build pipelines and tools'
        ],
        benefits: [
          'Competitive salary',
          'Remote work options',
          'Professional growth opportunities',
          'Team building activities'
        ],
        location: 'Baku, Azerbaijan',
        type: 'Full-time',
        category: 'Information Technology',
        experienceLevel: 'Mid Level',
        educationLevel: 'Bachelor\'s Degree',
        salaryMin: 2500,
        salaryMax: 3500,
        currency: 'AZN',
        skills: ['HTML', 'CSS', 'JavaScript', 'React', 'Responsive Design'],
        deadline: oneMonthFromNow,
        isActive: true,
        isFeatured: true,
        companyId: companies[0].id,
        postedBy: employers[0].id
      },
      {
        title: 'Accountant',
        description: 'We are seeking a detail-oriented Accountant to join our finance team.',
        responsibilities: [
          'Prepare financial reports and statements',
          'Manage accounts payable and receivable',
          'Ensure compliance with financial regulations',
          'Assist with budget preparation and forecasting'
        ],
        requirements: [
          '3+ years of accounting experience',
          'Knowledge of accounting principles and practices',
          'Proficiency in Excel and accounting software',
          'Bachelor\'s degree in Accounting or Finance'
        ],
        benefits: [
          'Competitive salary',
          'Health insurance',
          'Professional certification support',
          'Career advancement opportunities'
        ],
        location: 'Baku, Azerbaijan',
        type: 'Full-time',
        category: 'Finance',
        experienceLevel: 'Mid Level',
        educationLevel: 'Bachelor\'s Degree',
        salaryMin: 1800,
        salaryMax: 2500,
        currency: 'AZN',
        skills: ['Accounting', 'Financial Reporting', 'Excel', 'QuickBooks'],
        deadline: oneMonthFromNow,
        isActive: true,
        isFeatured: false,
        companyId: companies[1].id,
        postedBy: employers[1].id
      },
      {
        title: 'Digital Marketing Specialist',
        description: 'Join our creative team as a Digital Marketing Specialist and help grow our clients\' online presence.',
        responsibilities: [
          'Develop and implement digital marketing strategies',
          'Manage social media accounts and campaigns',
          'Create engaging content for various platforms',
          'Analyze campaign performance and provide reports'
        ],
        requirements: [
          '2+ years of experience in digital marketing',
          'Knowledge of SEO, SEM, and social media marketing',
          'Experience with Google Analytics and social media tools',
          'Strong creative and analytical skills'
        ],
        benefits: [
          'Competitive salary',
          'Flexible working hours',
          'Creative work environment',
          'Professional development opportunities'
        ],
        location: 'Baku, Azerbaijan',
        type: 'Full-time',
        category: 'Marketing',
        experienceLevel: 'Mid Level',
        educationLevel: 'Bachelor\'s Degree',
        salaryMin: 1500,
        salaryMax: 2200,
        currency: 'AZN',
        skills: ['Social Media Marketing', 'SEO', 'Content Creation', 'Google Analytics'],
        deadline: twoMonthsFromNow,
        isActive: true,
        isFeatured: true,
        companyId: companies[2].id,
        postedBy: employers[2].id
      },
      {
        title: 'Content Writer',
        description: 'We are looking for a talented Content Writer to create compelling content for our clients.',
        responsibilities: [
          'Create engaging content for websites, blogs, and social media',
          'Research industry-related topics',
          'Edit and proofread written pieces',
          'Collaborate with marketing team to develop content strategy'
        ],
        requirements: [
          'Proven experience as a content writer',
          'Excellent writing and editing skills in English and Azerbaijani',
          'Ability to research and process complex information',
          'Creative mindset with an eye for detail'
        ],
        benefits: [
          'Competitive salary',
          'Remote work options',
          'Flexible schedule',
          'Creative freedom'
        ],
        location: 'Baku, Azerbaijan',
        type: 'Part-time',
        category: 'Marketing',
        experienceLevel: 'Entry Level',
        educationLevel: 'Bachelor\'s Degree',
        salaryMin: 800,
        salaryMax: 1200,
        currency: 'AZN',
        skills: ['Content Writing', 'Copywriting', 'SEO Writing', 'Editing'],
        deadline: oneMonthFromNow,
        isActive: true,
        isFeatured: false,
        companyId: companies[2].id,
        postedBy: employers[2].id
      }
    ]);
    console.log('Jobs created successfully');

    // Create applications
    const applications = await Application.bulkCreate([
      {
        coverLetter: 'I am excited to apply for the Senior Software Engineer position at Tech Solutions. With my 5+ years of experience in web development and expertise in JavaScript, React, and Node.js, I believe I would be a valuable addition to your team.',
        resume: 'ali_mammadov_resume.pdf',
        status: 'pending',
        userId: jobSeekers[0].id,
        jobId: jobs[0].id
      },
      {
        coverLetter: 'I am writing to express my interest in the Digital Marketing Specialist position at Marketing Pro. With my experience in social media marketing and content creation, I am confident that I can help grow your clients\' online presence.',
        resume: 'leyla_aliyeva_resume.pdf',
        status: 'pending',
        userId: jobSeekers[1].id,
        jobId: jobs[3].id
      },
      {
        coverLetter: 'I am applying for the Accountant position at Finance Plus. With my background in finance and accounting, I believe I have the skills and experience necessary to excel in this role.',
        resume: 'farid_huseynov_resume.pdf',
        status: 'pending',
        userId: jobSeekers[2].id,
        jobId: jobs[2].id
      }
    ]);
    console.log('Applications created successfully');

    console.log('Database seeded successfully');
  } catch (error) {
    console.error('Error seeding database:', error);
  }
};

// Export the seed function
module.exports = seedDatabase;
