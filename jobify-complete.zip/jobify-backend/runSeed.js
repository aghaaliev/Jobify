const { exec } = require('child_process');

// Script to run the database seed
const seedScript = async () => {
  try {
    console.log('Starting database seed...');
    
    // Import the seed function
    const seedDatabase = require('./seedDatabase');
    
    // Run the seed function
    await seedDatabase();
    
    console.log('Database seed completed successfully');
  } catch (error) {
    console.error('Error running seed script:', error);
  }
};

// Run the seed script
seedScript();
