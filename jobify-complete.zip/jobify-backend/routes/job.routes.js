const express = require('express');
const router = express.Router();
const jobController = require('../controllers/job.controller');
const { verifyToken, isEmployer } = require('../middleware/auth.middleware');

// Public routes
router.get('/', jobController.getAllJobs);
router.get('/featured', jobController.getFeaturedJobs);
router.get('/categories', jobController.getJobCategories);
router.get('/search', jobController.searchJobs);
router.get('/:id', jobController.getJobById);

// Protected routes - Employer only
router.post('/', verifyToken, isEmployer, jobController.createJob);
router.put('/:id', verifyToken, isEmployer, jobController.updateJob);
router.delete('/:id', verifyToken, isEmployer, jobController.deleteJob);

module.exports = router;
