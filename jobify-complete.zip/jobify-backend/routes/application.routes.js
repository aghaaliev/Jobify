const express = require('express');
const router = express.Router();
const applicationController = require('../controllers/application.controller');
const { verifyToken, isJobSeeker, isEmployer } = require('../middleware/auth.middleware');

// Protected routes - Job seeker
router.post('/jobs/:jobId/apply', verifyToken, isJobSeeker, applicationController.applyForJob);
router.get('/my-applications', verifyToken, applicationController.getUserApplications);

// Protected routes - Employer
router.get('/jobs/:jobId/applications', verifyToken, isEmployer, applicationController.getJobApplications);
router.put('/:applicationId/status', verifyToken, isEmployer, applicationController.updateApplicationStatus);

// Common protected routes
router.get('/:applicationId', verifyToken, applicationController.getApplicationById);

module.exports = router;
