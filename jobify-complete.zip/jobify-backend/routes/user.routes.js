const express = require('express');
const router = express.Router();
const jobSeekerProfileController = require('../controllers/jobSeekerProfile.controller');
const { verifyToken, isJobSeeker } = require('../middleware/auth.middleware');

// Public routes
router.get('/public', jobSeekerProfileController.getAllPublicProfiles);
router.get('/user/:userId', jobSeekerProfileController.getProfileByUserId);

// Protected routes - Job seeker only
router.post('/', verifyToken, isJobSeeker, jobSeekerProfileController.createOrUpdateProfile);
router.put('/', verifyToken, isJobSeeker, jobSeekerProfileController.createOrUpdateProfile);
router.get('/me', verifyToken, isJobSeeker, jobSeekerProfileController.getCurrentUserProfile);
router.put('/visibility', verifyToken, isJobSeeker, jobSeekerProfileController.toggleProfileVisibility);

module.exports = router;
