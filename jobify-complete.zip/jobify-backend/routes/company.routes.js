const express = require('express');
const router = express.Router();
const companyController = require('../controllers/company.controller');
const { verifyToken, isEmployer } = require('../middleware/auth.middleware');

// Public routes
router.get('/', companyController.getAllCompanies);
router.get('/top', companyController.getTopCompanies);
router.get('/:id', companyController.getCompanyById);
router.get('/:id/jobs', companyController.getCompanyJobs);

// Protected routes - Employer only
router.post('/', verifyToken, isEmployer, companyController.createCompany);
router.put('/:id', verifyToken, isEmployer, companyController.updateCompany);

module.exports = router;
