# Jobify - Modern Job Posting Website for Azerbaijan

This package contains a simplified version of the Jobify website, designed to be easily deployed on any web hosting service.

## Contents

- `frontend/` - Contains the static HTML, CSS, and JavaScript files for the website
- `README.md` - This file with instructions

## Features

- Modern, responsive design with green color scheme
- Job listings with filtering and search functionality
- Company profiles
- Job seeker profiles
- User registration and login
- Backend API integration

## Backend API

The backend API is deployed at:
http://5000-irnn9aujbf05lux8s84wx-13f789e2.manus.computer/api

API endpoints:
- `/jobs` - Job listings
- `/companies` - Company profiles
- `/users` - User profiles
- `/auth` - Authentication (login/register)
- `/applications` - Job applications

## Deployment Instructions

1. Upload the contents of the `frontend` folder to your web hosting service
2. Ensure the API configuration in `js/main.js` points to the correct backend URL
3. No additional configuration is needed as this is a static website

## Database

The backend is connected to a PostgreSQL database with sample data including:
- Job categories
- Company profiles
- Job listings
- User accounts (employers and job seekers)

## Customization

To customize the website:
- Edit the HTML files to change the structure
- Modify the inline CSS or add your own stylesheet
- Update the JavaScript in `js/main.js` to change functionality

## Login Credentials for Testing

### Employer Account
- Email: employer@example.com
- Password: password123

### Job Seeker Account
- Email: jobseeker@example.com
- Password: password123

## Future Improvements

- Add more interactive features
- Implement real-time notifications
- Enhance the search functionality with filters
- Add analytics dashboard for employers
